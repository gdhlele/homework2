package demo.domain;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.Entity;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Customer {

    private String customerName;
    private String cardNumber;
    private String cardOwner;
    private String cvs;

    public Customer(String customerName) {
        this.customerName = customerName;
    }

    public Customer(String customerName, String cardNumber, String cardOwner, String cvs) {
        this.customerName = customerName;
        this.cardNumber = cardNumber;
        this.cardOwner = cardOwner;
        this.cvs = cvs;
    }
}

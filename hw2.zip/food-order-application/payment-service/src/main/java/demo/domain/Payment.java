package demo.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class Payment {

    @Id
    @GeneratedValue
    private Long id;

    private String orderId;
    private String restaurantName;
    private String customerName;
    private double totalPrice;

    @OneToOne
    private Customer customer;

    public Payment() {
    }

    public Payment(Customer customer) {
        this.customer = customer;
    }

    @JsonCreator
    public Payment(@JsonProperty("orderId") String orderId) {
        this.customer = new Customer(customerName);
    }


}

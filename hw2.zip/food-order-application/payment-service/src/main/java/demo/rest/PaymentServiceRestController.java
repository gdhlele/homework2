package demo.rest;

import demo.domain.Customer;
import demo.domain.Payment;
import demo.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class PaymentServiceRestController {

    @Autowired
    private PaymentService paymentService;


    @RequestMapping(value = "/paidOrder", method = RequestMethod.POST)
    public void savePaidOrder(@RequestBody Payment payment){
        paymentService.savePayment(payment);
    }

    @RequestMapping(value = "/customer/{customerName}", method = RequestMethod.GET)
    public Customer getCustomerInfo(@PathVariable String customerName) {
        return paymentService.getICustomerInfo(customerName);
    }

}

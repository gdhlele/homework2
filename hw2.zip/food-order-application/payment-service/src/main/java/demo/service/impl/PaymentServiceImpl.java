package demo.service.impl;

import demo.domain.Customer;
import demo.domain.Payment;
import demo.domain.PaymentRepository;
import demo.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentServiceImpl implements PaymentService{

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public void savePayment(Payment payment) {
        paymentRepository.save(payment);
    }

    @Override
    public Customer getICustomerInfo(String customerName) {
        return paymentRepository.findByCustomerName(customerName);
    }
}

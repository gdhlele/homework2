package demo.service;


import demo.domain.Customer;
import demo.domain.Payment;
import demo.domain.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;

public interface PaymentService {
    void savePayment(Payment payment);

    Customer getICustomerInfo(String customerName);
}

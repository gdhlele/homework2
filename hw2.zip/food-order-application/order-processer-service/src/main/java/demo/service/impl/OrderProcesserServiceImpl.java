package demo.service.impl;


import demo.domain.Food;
import demo.domain.Order;
import demo.domain.OrderRepository;
import demo.service.OrderProcesserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderProcesserServiceImpl implements OrderProcesserService{

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public List<Food> getMenu(String restaurantName) {
        return orderRepository.findFoodByRestaurantName(restaurantName);
    }

    @Override
    public void placeOrder(Order order) {
        orderRepository.save(order);
    }
}

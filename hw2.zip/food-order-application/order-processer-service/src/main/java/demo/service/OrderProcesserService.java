package demo.service;


import demo.domain.Food;
import demo.domain.Order;
import demo.domain.OrderedFood;

import java.util.List;

public interface OrderProcesserService {

    List<Food> getMenu(String restaurantName);

    void placeOrder(Order order);
}

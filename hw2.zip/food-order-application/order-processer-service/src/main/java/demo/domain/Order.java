package demo.domain;


import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@JsonInclude(JsonInclude.Include.NON_NULL)

public class Order {

    @Id
    @GeneratedValue
    private Long id;

    private String customerName;
    private String restaurantName;

    @OneToMany(targetEntity = OrderedFood.class, cascade = CascadeType.ALL)
    private OrderedFood food;

    private Date orderTime = new Date();

    public Order() {
        this.food = new OrderedFood();
    }

    public Order(String name, int quantity, String notes) {
        this.food = new OrderedFood(name, quantity, notes);
    }


    @JsonCreator
    public Order(@JsonProperty("food") OrderedFood food) {
        this.food = food;
    }

}

package demo.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class OrderedFood {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private int quantity;
    private String notes;


    public OrderedFood() {

    }

    @JsonCreator
    public OrderedFood(@JsonProperty("name") String name,
                       @JsonProperty("quantity") int quantity,
                       @JsonProperty("notes") String notes) {
        this.name = name;
        this.quantity = quantity;
        this.notes = notes;
    }

}

package demo.rest;

import demo.domain.Food;
import demo.domain.Order;
import demo.service.OrderProcesserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class OrderProcesserRestController {


    @Autowired
    private OrderProcesserService orderProcesserService;

    @RequestMapping(value = "/menu/{restaurantName}", method = RequestMethod.GET)
    public List<Food> getMenu(@PathVariable String restaurantName) {
        return orderProcesserService.getMenu(restaurantName);
    }

    @RequestMapping(value = "/order", method = RequestMethod.POST)
    public void placeOrder(@RequestBody Order order){
        orderProcesserService.placeOrder(order);
    }
}

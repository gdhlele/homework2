package demo.REST;

import demo.service.UploadService;
import demo.service.impl.UploadServiceImpl;
import demo.domain.Restaurant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RestaurantUploadController {


    private UploadService uploadService;

    @Autowired
    public RestaurantUploadController(UploadService uploadService) {
        this.uploadService = uploadService;
    }

    @RequestMapping(value = "/restaurantMenu", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public void upload(@RequestBody List<Restaurant> restaurants) {
        this.uploadService.saveRestaurantInfo(restaurants);
    }

}

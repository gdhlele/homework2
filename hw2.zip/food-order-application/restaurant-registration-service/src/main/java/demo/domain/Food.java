package demo.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class Food {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private double price;

    public Food() {
    }

    @JsonCreator
    public Food(
            @JsonProperty("name") String name,
            @JsonProperty("price") double price) {
        this.name = name;
        this.price = price;
    }
}

package demo.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "Restaurant")

public class Restaurant {


    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String address;

    @OneToMany(targetEntity = Food.class, cascade = CascadeType.ALL)
    private Food food;

    public Restaurant() {
        this.food = new Food();
    }

    public Restaurant(String name, double price) {
        this.food = new Food(name, price);
    }

    @JsonCreator
    public Restaurant(@JsonProperty("food") Food food) {
        this.food = food;
    }
}

package demo.service.impl;

import demo.domain.Restaurant;
import demo.domain.RestaurantRepository;
import demo.service.UploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class UploadServiceImpl implements UploadService {

    private RestaurantRepository restaurantRepository;

    @Autowired
    public UploadServiceImpl(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    @Override
    public List<Restaurant> saveRestaurantInfo(List<Restaurant> restaurants) {
        return restaurantRepository.save(restaurants);
    }
}

package demo.service;

import demo.domain.Restaurant;

import java.util.List;

public interface UploadService {
    List<Restaurant> saveRestaurantInfo(List<Restaurant> restaurants);
}
